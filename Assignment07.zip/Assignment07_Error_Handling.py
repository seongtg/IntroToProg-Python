#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  August 4th, 2015
# ChangeLog: (Who, When, What)
#   RRoot, 08/04/2015, Created Script
#   SChang, 12/03/1018, Edited Script
#-------------------------------------------------#
# Beginning of try - except block
try:
    decValue = 10/0
    print(decValue)
# exception class Zero division class exists
# prints custom error message
except ZeroDivisionError as e:
    print("Cannot divide number by Zero!")
# prints python error message
except Exception as e:
    print("Python error details: ")
    print(e)