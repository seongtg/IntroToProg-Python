#-------------------------------------------------#
# Title: Python Pickle
# Dev:   SChang
# Date:  December 4th, 2018
# ChangeLog: (Who, When, What)
#   SChang, 12/04/1018, Created Script
#-------------------------------------------------#

# Load data to file
import pickle
# Data in Tuple
sports_players = {"Greg": "Bobcats", "Gordon": "Stingrays"}
# Data is saved to a text file by pickle.dump, which loads the data into file
objFile = (("C:\\_PythonClass\\Assignment07\\Players.dat"))
pickle.dump(sports_players, open("objFile","wb"))
# Data is then read with the pickle.load command
objFile = (("C:\\_PythonClass\\Assignment07\\Players.dat"))
sports_players = pickle.load(open("objFile","rb"))
# Data is displayed
print(sports_players)